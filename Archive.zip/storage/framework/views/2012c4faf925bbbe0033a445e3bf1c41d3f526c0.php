<?php $__env->startSection('head-content'); ?>
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Data Pendaftar</h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">
                <a href="<?php echo e(route('pendaftaran.create')); ?>" class="btn btn-success"><i style="color: white"
                        class="fas fa-plus"></i></a>
                &nbsp; <b>Tambah</b>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <?php echo e($message); ?>

                </div>
            <?php endif; ?>
            <div class="white-box">
                <div class="table-responsive">
                    <table class="table text-nowrap">
                        <thead>
                            <tr>
                                <th class="border-top-0">Nama</th>
                                <th class="border-top-0">Jenis Kelamin</th>
                                <th class="border-top-0">Tempat Lahir</th>
                                <th class="border-top-0">Tanggal Lahir</th>
                                <th class="border-top-0">Alamat</th>
                                <th class="border-top-0">No Telp</th>
                                <th class="border-top-0">Status</th>
                                <th class="border-top-0">#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($datas->nama); ?></td>
                                    <td><?php echo e($datas->jenis_kelamin); ?></td>
                                    <td><?php echo e($datas->tempat_lahir); ?></td>
                                    <td><?php echo e($datas->tgl_lahir); ?></td>
                                    <td><?php echo e($datas->alamat); ?></td>
                                    <td><?php echo e($datas->no_telp); ?></td>
                                    <?php if($datas->status == '0'): ?>
                                        <td style="background-color: yellow">
                                            <label>Pending</label>
                                        </td>
                                    <?php elseif($datas->status == '1'): ?>
                                        <td style="background-color: rgb(75, 221, 75)">
                                            <label>Diterima</label>
                                        </td>
                                    <?php elseif($datas->status == '2'): ?>
                                        <td style="background-color: red">
                                            <label>Ditolak</label>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <a href="<?php echo e(route('pendaftaran.edit', ['pendaftaran' => $datas->id])); ?>"
                                            class="btn btn-warning">Edit</a>

                                        <a data-id="<?php echo e($datas->id); ?>" style="color: white"
                                            class="btn btn-danger btn-hapus">Hapus</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.btn-hapus').click(function(e) {
            e.preventDefault();
            var id = $(this).data('id');
            $.ajax({
                type: 'DELETE',
                // method: 'DELETE',
                url: '/admin/pendaftaran/' + id
            }).then(function(data) {
                location.reload()
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/mywww/juri_eo/resources/views/datas/pendaftar.blade.php ENDPATH**/ ?>