<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo e(asset('tmpl/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lgn/css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lgn/css/util.css')); ?>" rel="stylesheet">
    <!--===============================================================================================-->
</head>

<body>

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-t-85 p-b-20">
                <form method="POST" action="<?php echo e(route('login.klien.post')); ?>" class="login100-form validate-form">
                    <?php echo csrf_field(); ?>
                    <span class="login100-form-title p-b-70">
                        EO <br> LOGIN
                    </span>
                    <?php if($message = Session::get('error')): ?>

                        <div class="alert alert-danger alert-dismissable">
                            Masukan data dengan benar
                        </div>
                    <?php endif; ?>
                    <div class="wrap-input100 validate-input m-t-85 m-b-35" data-validate="Enter username">
                        <input class="input100" type="text" name="username" autocomplete="off">
                        <span class="focus-input100" data-placeholder="Username"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-50" data-validate="Enter password">
                        <input class="input100" type="password" name="password">
                        <span class="focus-input100" data-placeholder="Password"></span>
                    </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn">
                            Login
                        </button>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('tmpl/plugins/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('tmpl/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lgn/js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH /Users/admin/mywww/juri_eo/resources/views/front/auth/login.blade.php ENDPATH**/ ?>