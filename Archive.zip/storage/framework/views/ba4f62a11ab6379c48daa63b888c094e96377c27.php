<?php $__env->startSection('head-content'); ?>
    <div class="row align-items-center">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h4 class="page-title">Tambah Data Pendaftaran</h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">
                <form method="POST" action="<?php echo e(route($link, !empty($acara) ? $acara : '')); ?>">
                    <?php echo method_field($method); ?>
                    <?php echo csrf_field(); ?>
                    <input name="id" value="<?php echo e(!empty($data->id) ? $data->id : ''); ?>" hidden>
                    <div class="form-group">
                        <label>Nama</label>
                        <input class="form-control" name="nama" type="text"
                            value="<?php echo e(!empty($data->nama) ? $data->nama : ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Jenis Kelamin</label>
                        <select class="form-select" name="jenis_kelamin" required>
                            <option value="laki-laki">Laki-laki</option>
                            <option value="perempuan">Perempuan</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input class="form-control" name="tempat_lahir" type="text"
                            value="<?php echo e(!empty($data->tempat_lahir) ? $data->tempat_lahir : ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input class="form-control datepicker" name="tanggal_lahir" readonly required type="text"
                            value="<?php echo e(!empty($data->tgl_lahir) ? $data->tgl_lahir : ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Alamat</label>
                        <input class="form-control" name="alamat" type="text"
                            value="<?php echo e(!empty($data->alamat) ? $data->alamat : ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>No Telp</label>
                        <input class="form-control" name="no_telp" type="number"
                            value="<?php echo e(!empty($data->no_telp) ? $data->no_telp : ''); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select class="form-select" name="status" required>
                            <option value="1" selected>Diterima</option>
                            <option value="2">Ditolak</option>
                        </select>
                    </div>
                    <button class="btn btn-success" type="submit">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/mywww/juri_eo/resources/views/datas/formpendaftaran.blade.php ENDPATH**/ ?>