<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">
                <form method="POST" action="<?php echo e(route('info.post')); ?>">
                    
                    <?php echo csrf_field(); ?>
                    <p style="text-align: center; font-weight: bold; font-size: 25px">INFO PENDAFTARAN</p>
                    <textarea class="summernote" name="info"><?php echo e(!empty($data->desc) ? $data->desc : ''); ?></textarea>
                    <button class="btn btn-success">Save</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/mywww/juri_eo/resources/views/datas/info.blade.php ENDPATH**/ ?>